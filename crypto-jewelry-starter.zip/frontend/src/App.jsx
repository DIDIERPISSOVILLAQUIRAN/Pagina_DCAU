import React, { useState } from 'react'
import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import Landing from './pages/Landing.jsx'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import Wallet from './pages/Wallet.jsx'
import Jewelry from './pages/Jewelry.jsx'
import Admin from './pages/Admin.jsx'

export default function App(){
  const [token, setToken] = useState(localStorage.getItem('token'))
  const [dark, setDark] = useState(false)
  const navigate = useNavigate()

  const logout = () => {
    localStorage.removeItem('token'); setToken(null); navigate('/')
  }

  return (
    <div className={dark ? 'dark' : ''}>
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100">
        <nav className="flex gap-4 p-4 border-b border-slate-200 dark:border-slate-800">
          <Link to="/">🏠</Link>
          <Link to="/wallet">💼</Link>
          <Link to="/jewelry">💍</Link>
          <Link to="/admin">🛠️</Link>
          {!token ? <Link to="/login" className="ml-auto">🔐 Login</Link>
                   : <button onClick={logout} className="ml-auto">🚪 Logout</button>}
          <button onClick={()=>setDark(d=>!d)} className="px-2">🌓</button>
          <LangSwitcher />
        </nav>
        <Routes>
          <Route path="/" element={<Landing/>} />
          <Route path="/login" element={<Login onAuth={(t)=>{localStorage.setItem('token',t); setToken(t)}} />} />
          <Route path="/register" element={<Register />} />
          <Route path="/wallet" element={<Wallet />} />
          <Route path="/jewelry" element={<Jewelry />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
        <footer className="p-6 text-center opacity-70">© 2025 Crypto & Jewelry</footer>
      </div>
    </div>
  )
}

function LangSwitcher(){
  const [lang, setLang] = useState('es')
  const change = () => {
    const next = lang === 'es' ? 'en' : 'es'
    import('i18next').then(({default: i18n})=>i18n.changeLanguage(next))
    setLang(next)
  }
  return <button onClick={change}>🌐 {lang.toUpperCase()}</button>
}
