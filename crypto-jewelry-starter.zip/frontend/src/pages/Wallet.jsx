import React, { useEffect, useState } from 'react'
import axios from 'axios'

const API = import.meta.env.VITE_API_BASE

export default function Wallet(){
  const [data, setData] = useState(null)
  const token = localStorage.getItem('token')

  useEffect(()=>{
    (async()=>{
      const { data } = await axios.get(`${API}/wallet/dashboard`, { headers: { Authorization: `Bearer ${token}`}})
      setData(data)
    })()
  }, [])

  if(!token) return <main className="p-6">Necesitas iniciar sesión.</main>

  return (
    <main className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Cartera</h1>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 rounded-xl bg-white/70 dark:bg-slate-800 shadow">
          <h2 className="font-semibold mb-2">Balances</h2>
          <ul>{data?.balances?.map(b=>(<li key={b.token}>{b.token}: {b.amount} (~${b.usd})</li>))}</ul>
        </div>
        <div className="p-4 rounded-xl bg-white/70 dark:bg-slate-800 shadow">
          <h2 className="font-semibold mb-2">Historial</h2>
          <ul className="max-h-48 overflow-auto">
            {data?.recent?.map(tx=>(<li key={tx._id}>{tx.direction} {tx.amount} {tx.token}</li>))}
          </ul>
        </div>
      </div>
    </main>
  )
}
