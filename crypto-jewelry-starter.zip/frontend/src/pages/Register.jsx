import React, { useState } from 'react'
import axios from 'axios'
const API = import.meta.env.VITE_API_BASE

export default function Register(){
  const [form, setForm] = useState({ email:'', password:'' })
  const [done, setDone] = useState(false)
  const submit = async (e) => {
    e.preventDefault()
    await axios.post(`${API}/auth/register`, form)
    setDone(true)
  }
  return (
    <main className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Registro</h1>
      {!done ? (
        <form onSubmit={submit} className="grid gap-3">
          <input placeholder="Email" className="p-2 rounded bg-white/70 dark:bg-slate-800" value={form.email} onChange={e=>setForm({...form, email:e.target.value})}/>
          <input type="password" placeholder="Contraseña" className="p-2 rounded bg-white/70 dark:bg-slate-800" value={form.password} onChange={e=>setForm({...form, password:e.target.value})}/>
          <button className="px-4 py-2 bg-indigo-600 text-white rounded">Crear cuenta</button>
        </form>
      ):(
        <p>Cuenta creada. Ve a <a href="/login" className="underline">Login</a></p>
      )}
    </main>
  )
}
