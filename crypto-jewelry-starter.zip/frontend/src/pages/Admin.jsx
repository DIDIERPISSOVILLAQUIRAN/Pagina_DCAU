import React, { useEffect, useState } from 'react'
import axios from 'axios'
const API = import.meta.env.VITE_API_BASE

export default function Admin(){
  const [stats, setStats] = useState(null)
  const token = localStorage.getItem('token')

  useEffect(()=>{
    (async()=>{
      try{
        const { data } = await axios.get(`${API}/admin/stats`, { headers: { Authorization: `Bearer ${token}`}})
        setStats(data)
      }catch(e){}
    })()
  }, [])

  if(!token) return <main className="p-6">Necesitas iniciar sesión como admin.</main>

  return (
    <main className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Administración</h1>
      <div className="grid md:grid-cols-3 gap-4">
        <Card title="Usuarios" value={stats?.users ?? '—'} />
        <Card title="Pedidos" value={stats?.orders ?? '—'} />
        <Card title="Transacciones" value={stats?.txs ?? '—'} />
      </div>
      <p className="opacity-70 mt-4">Gestión de inventario, usuarios y permisos disponible vía API (endpoints incluidos).</p>
    </main>
  )
}

function Card({ title, value }){
  return <div className="p-4 rounded-xl bg-white/70 dark:bg-slate-800 shadow">
    <div className="opacity-70 text-sm">{title}</div>
    <div className="text-3xl font-extrabold">{value}</div>
  </div>
}
