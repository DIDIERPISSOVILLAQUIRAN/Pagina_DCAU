import React, { useEffect, useState } from 'react'
import axios from 'axios'
const API = import.meta.env.VITE_API_BASE

export default function Jewelry(){
  const [items, setItems] = useState([])
  const [q, setQ] = useState('')
  const [metal, setMetal] = useState('')
  const [min, setMin] = useState(0)
  const [max, setMax] = useState(2000)

  const fetchData = async () => {
    const { data } = await axios.get(`${API}/jewelry/catalog`, { params: { q, metal, min, max } })
    setItems(data.items)
  }

  useEffect(()=>{ fetchData() }, [])

  return (
    <main className="max-w-5xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Joyería</h1>
      <div className="grid md:grid-cols-4 gap-2 mb-4">
        <input className="p-2 rounded bg-white/70 dark:bg-slate-800" placeholder="Buscar" value={q} onChange={e=>setQ(e.target.value)}/>
        <select className="p-2 rounded bg-white/70 dark:bg-slate-800" value={metal} onChange={e=>setMetal(e.target.value)}>
          <option value="">Todos</option>
          <option value="gold">Oro</option>
          <option value="silver">Plata</option>
          <option value="platinum">Platino</option>
        </select>
        <input className="p-2 rounded bg-white/70 dark:bg-slate-800" type="number" placeholder="Mín" value={min} onChange={e=>setMin(e.target.value)}/>
        <input className="p-2 rounded bg-white/70 dark:bg-slate-800" type="number" placeholder="Máx" value={max} onChange={e=>setMax(e.target.value)}/>
        <button onClick={fetchData} className="px-4 py-2 bg-indigo-600 text-white rounded md:col-span-4">Filtrar</button>
      </div>
      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {items.map(p=>(
          <article key={p._id} className="p-4 rounded-xl bg-white/70 dark:bg-slate-800 shadow">
            <div className="aspect-square bg-slate-200 dark:bg-slate-700 rounded mb-2 flex items-center justify-center">IMG</div>
            <h3 className="font-semibold">{p.title}</h3>
            <p className="text-sm opacity-80">{p.metal} • {p.weight || '?'} g • {p.certification?.join(', ')}</p>
            <p className="font-bold">${p.priceUSD}</p>
            <button className="mt-2 px-3 py-1 bg-emerald-600 text-white rounded">Añadir al carrito</button>
          </article>
        ))}
      </div>
    </main>
  )
}
