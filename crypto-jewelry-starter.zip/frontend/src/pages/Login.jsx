import React, { useState } from 'react'
import axios from 'axios'

const API = import.meta.env.VITE_API_BASE

export default function Login({ onAuth }){
  const [form, setForm] = useState({ email:'', password:'', totp:'' })
  const [error, setError] = useState('')

  const submit = async (e) => {
    e.preventDefault()
    try {
      const { data } = await axios.post(`${API}/auth/login`, form)
      onAuth?.(data.token)
    } catch (e) {
      setError(e.response?.data?.error || 'Error')
    }
  }

  return (
    <main className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Login</h1>
      <form onSubmit={submit} className="grid gap-3">
        <input placeholder="Email" className="p-2 rounded bg-white/70 dark:bg-slate-800" value={form.email} onChange={e=>setForm({...form, email:e.target.value})}/>
        <input type="password" placeholder="Contraseña" className="p-2 rounded bg-white/70 dark:bg-slate-800" value={form.password} onChange={e=>setForm({...form, password:e.target.value})}/>
        <input placeholder="Código 2FA (si aplica)" className="p-2 rounded bg-white/70 dark:bg-slate-800" value={form.totp} onChange={e=>setForm({...form, totp:e.target.value})}/>
        <button className="px-4 py-2 bg-indigo-600 text-white rounded">Ingresar</button>
        {error && <p className="text-red-500">{error}</p>}
      </form>
      <p className="mt-2"><a className="underline" href="/register">Crear cuenta</a></p>
    </main>
  )
}
