import React from 'react'
import { useTranslation } from 'react-i18next'

export default function Landing(){
  const { t } = useTranslation()
  return (
    <main className="max-w-5xl mx-auto p-6">
      <section className="text-center py-12">
        <h1 className="text-4xl font-extrabold">{t('hero_title')}</h1>
        <p className="mt-2 opacity-80">{t('hero_sub')}</p>
        <a href="/register" className="inline-block mt-6 px-5 py-3 bg-indigo-600 text-white rounded-lg shadow">{t('cta')}</a>
      </section>

      <section className="grid md:grid-cols-3 gap-6 my-12">
        <div className="p-6 rounded-2xl bg-white/70 dark:bg-slate-800 shadow">💎 Joyería certificada</div>
        <div className="p-6 rounded-2xl bg-white/70 dark:bg-slate-800 shadow">🔐 Seguridad 2FA + JWT</div>
        <div className="p-6 rounded-2xl bg-white/70 dark:bg-slate-800 shadow">⛓️ Web3 (ethers)</div>
      </section>

      <section className="my-12">
        <h2 className="text-2xl font-bold">{t('about_title')}</h2>
        <p className="opacity-80">Misión, visión y valores con enfoque RSE, ISO y LBMA visibles.</p>
      </section>

      <section className="my-12">
        <h2 className="text-2xl font-bold">{t('services_title')}</h2>
        <ul className="list-disc ml-6">
          <li>Gestión de joyas (catálogo, filtros, carrito, pedidos)</li>
          <li>Servicios cripto (balances, enviar/recibir, historial)</li>
        </ul>
      </section>

      <section className="my-12">
        <h2 className="text-2xl font-bold">{t('contact_title')}</h2>
        <form className="grid gap-3 max-w-md">
          <input className="p-2 rounded bg-white/70 dark:bg-slate-800" placeholder="Nombre" />
          <input className="p-2 rounded bg-white/70 dark:bg-slate-800" placeholder="Correo" />
          <textarea className="p-2 rounded bg-white/70 dark:bg-slate-800" placeholder="Mensaje" />
          <button className="px-4 py-2 bg-indigo-600 text-white rounded">Enviar</button>
        </form>
      </section>
    </main>
  )
}
