import mongoose from 'mongoose';

const txSchema = new mongoose.Schema({
  userId: { type: mongoose.Types.ObjectId, ref: 'User' },
  chain: { type: String, enum: ['ethereum','bitcoin','other'], default: 'ethereum' },
  direction: { type: String, enum: ['in','out'], required: true },
  amount: Number,
  token: { type: String, default: 'ETH' },
  address: String,
  txHash: String,
  feeUSD: Number
}, { timestamps: true });

export default mongoose.model('Tx', txSchema);
