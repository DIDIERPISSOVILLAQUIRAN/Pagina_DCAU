import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
  userId: { type: mongoose.Types.ObjectId, ref: 'User' },
  items: [{
    productId: { type: mongoose.Types.ObjectId, ref: 'Product' },
    qty: Number,
    priceUSD: Number
  }],
  status: { type: String, enum: ['pending','paid','shipped','delivered','cancelled'], default: 'pending' },
  payment: {
    method: { type: String, enum: ['card','paypal','crypto'], default: 'crypto' },
    txId: String,
    invoiceUrl: String
  },
  shipping: {
    provider: { type: String, enum: ['DHL','FedEx','Deprisa'], default: 'DHL' },
    tracking: String
  }
}, { timestamps: true });

export default mongoose.model('Order', orderSchema);
