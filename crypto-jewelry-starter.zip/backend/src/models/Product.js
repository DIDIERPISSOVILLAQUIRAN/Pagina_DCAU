import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  images: [String],
  metal: { type: String, enum: ['gold','silver','platinum','other'], default: 'gold' },
  weight: Number,
  certification: [String], // e.g., ['LBMA','ISO 9001']
  priceUSD: Number,
  stock: { type: Number, default: 0 },
  category: { type: String, default: 'ring' },
}, { timestamps: true });

export default mongoose.model('Product', productSchema);
