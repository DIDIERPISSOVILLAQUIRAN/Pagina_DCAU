import jwt from 'jsonwebtoken';

export const sign = (payload, opts={}) => jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d', ...opts });
export const verify = (token) => jwt.verify(token, process.env.JWT_SECRET);
