import express from 'express';
import Product from '../models/Product.js';
import Order from '../models/Order.js';
import { auth } from '../middleware/auth.js';

const router = express.Router();

router.get('/catalog', async (req, res) => {
  const { q, metal, min=0, max=1000000 } = req.query;
  const filter = { priceUSD: { $gte: Number(min), $lte: Number(max) } };
  if (metal) filter.metal = metal;
  if (q) filter.title = { $regex: q, $options: 'i' };
  const items = await Product.find(filter).limit(200);
  res.json({ items });
});

router.post('/order', auth, async (req, res) => {
  const { items, payment, shipping } = req.body;
  // TODO: integrar pasarelas (card/PayPal/cripto)
  const order = await Order.create({ userId: req.user.uid, items, payment, shipping });
  res.json({ ok: true, orderId: order._id });
});

router.get('/order/:id', auth, async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order || order.userId.toString() !== req.user.uid) return res.status(404).json({ error: 'Not found' });
  res.json({ order });
});

export default router;
