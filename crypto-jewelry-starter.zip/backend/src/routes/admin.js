import express from 'express';
import { auth } from '../middleware/auth.js';
import { requireRole } from '../middleware/roles.js';
import User from '../models/User.js';
import Product from '../models/Product.js';
import Order from '../models/Order.js';
import Tx from '../models/Tx.js';

const router = express.Router();

router.use(auth, requireRole('admin','support','seller'));

router.get('/stats', async (req, res) => {
  const [users, orders, txs] = await Promise.all([
    User.countDocuments(),
    Order.countDocuments(),
    Tx.countDocuments()
  ]);
  res.json({ users, orders, txs });
});

// Inventario
router.post('/product', async (req, res) => {
  const p = await Product.create(req.body);
  res.json({ ok: true, product: p });
});

router.patch('/product/:id', async (req, res) => {
  const p = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json({ ok: true, product: p });
});

router.delete('/product/:id', async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

// Usuarios
router.patch('/user/:id/role', async (req, res) => {
  const u = await User.findByIdAndUpdate(req.params.id, { role: req.body.role }, { new: true });
  res.json({ ok: true, user: u });
});

export default router;
