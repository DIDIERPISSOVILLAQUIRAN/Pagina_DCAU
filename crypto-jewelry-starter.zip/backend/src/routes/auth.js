import express from 'express';
import bcrypt from 'bcryptjs';
import speakeasy from 'speakeasy';
import QRCode from 'qrcode';
import User from '../models/User.js';
import { sign } from '../utils/jwt.js';

const router = express.Router();

router.post('/register', async (req, res) => {
  const { email, password } = req.body;
  const exists = await User.findOne({ email });
  if (exists) return res.status(400).json({ error: 'Email already used' });
  const passwordHash = await bcrypt.hash(password, 10);
  const user = await User.create({ email, passwordHash });
  res.json({ ok: true, userId: user._id });
});

router.post('/login', async (req, res) => {
  const { email, password, totp } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(400).json({ error: 'Invalid credentials' });

  if (user.twoFA?.enabled) {
    const verified = speakeasy.totp.verify({
      secret: user.twoFA.secret,
      encoding: 'base32',
      token: totp,
      window: 1
    });
    if (!verified) return res.status(401).json({ error: 'Invalid 2FA token' });
  }
  const token = sign({ uid: user._id.toString(), role: user.role, email: user.email });
  res.json({ token, role: user.role });
});

router.post('/2fa/setup', async (req, res) => {
  const { userId } = req.body;
  const secret = speakeasy.generateSecret({ name: process.env.APP_NAME || 'App' });
  const otpauth = secret.otpauth_url;
  const qr = await QRCode.toDataURL(otpauth);
  await User.findByIdAndUpdate(userId, { twoFA: { enabled: false, secret: secret.base32 } });
  res.json({ qr, secret: secret.base32 });
});

router.post('/2fa/enable', async (req, res) => {
  const { userId, token } = req.body;
  const user = await User.findById(userId);
  const verified = speakeasy.totp.verify({
    secret: user.twoFA.secret,
    encoding: 'base32',
    token,
    window: 1
  });
  if (!verified) return res.status(400).json({ error: 'Invalid token' });
  user.twoFA.enabled = true;
  await user.save();
  res.json({ ok: true });
});

router.post('/profile', async (req, res) => {
  const { userId, profile } = req.body;
  await User.findByIdAndUpdate(userId, { profile });
  res.json({ ok: true });
});

router.post('/kyc/submit', async (req, res) => {
  // Stub: integrar proveedor KYC (Onfido, SumSub, etc.)
  res.json({ ok: true, status: 'submitted' });
});

export default router;
