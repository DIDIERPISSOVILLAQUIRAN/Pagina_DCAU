import express from 'express';
import Tx from '../models/Tx.js';
import { auth } from '../middleware/auth.js';

const router = express.Router();

// Dashboard: balances simulados + historial
router.get('/dashboard', auth, async (req, res) => {
  const recent = await Tx.find({ userId: req.user.uid }).sort({ createdAt: -1 }).limit(20);
  // En producción: leer on-chain (ethers/bitcoinlib) y consolidar
  res.json({
    balances: [
      { token: 'ETH', amount: 1.2345, usd: 4200.11 },
      { token: 'USDC', amount: 250.00, usd: 250.00 },
    ],
    recent
  });
});

// Recibir: generar dirección (stub) y QR
router.post('/receive', auth, async (req, res) => {
  const { chain='ethereum' } = req.body;
  // Stub: generar address custodial/externa
  const address = '0xDEMOADDRESS000000000000000000000000000000';
  res.json({ address });
});

// Enviar: simulado, persistimos y devolvemos txId
router.post('/send', auth, async (req, res) => {
  const { chain='ethereum', token='ETH', amount=0, address } = req.body;
  const tx = await Tx.create({
    userId: req.user.uid, chain, direction: 'out', amount, token, address, feeUSD: 1.25, txHash: '0xSIMULATED'
  });
  res.json({ ok: true, tx });
});

export default router;
