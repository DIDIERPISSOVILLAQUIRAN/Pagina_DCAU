import mongoose from 'mongoose';
import 'dotenv/config';
import Product from '../models/Product.js';

await mongoose.connect(process.env.MONGO_URI);

await Product.deleteMany({});
await Product.insertMany([
  { title: 'Anillo Solitario Oro 18k', description: 'Acabado espejo', images: [], metal: 'gold', weight: 3.2, certification: ['LBMA'], priceUSD: 650, stock: 10, category: 'ring' },
  { title: 'Pulsera Plata 925', description: 'Hecho a mano', images: [], metal: 'silver', weight: 8.5, certification: ['ISO 9001'], priceUSD: 120, stock: 25, category: 'bracelet' }
]);

console.log('Seed done');
process.exit(0);
