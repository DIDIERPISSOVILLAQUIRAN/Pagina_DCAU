# Mapa de Requisitos (Cumplimiento)

Incluye: responsive, SSL/HTTPS (mediante proxy), integración blockchain (ethers - stub),
multilenguaje, roles, login/registro con JWT, 2FA TOTP, recuperación (por implementar),
perfil/KYC (stub), wallet (balances, historial, enviar/recibir simulados), landing,
catálogo joyería con filtros, carrito (UI por implementar), pagos (stubs), facturación (stub),
pedidos y estados, transportadoras (stubs), backoffice (stats + endpoints), SEO, modo oscuro,
blog (pendiente carpeta /blog), y Docker.

Este starter es la base para extender a producción.
